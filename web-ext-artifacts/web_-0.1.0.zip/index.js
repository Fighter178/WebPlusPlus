"use strict";
const currentVersion = "0.1.0";
let updateRequired = false;
let unsupportedBrowser = false;
(async () => {
    const browserInfo = await browser.runtime.getBrowserInfo();
    if (browserInfo.vendor !== "Mozilla" || browserInfo.name !== "Firefox") {
        unsupportedBrowser = true;
        browser.tabs.create({
            title: "",
            url: browser.runtime.getURL("ui/unsupported/unsupported.html"),
        });
    }
})();
browser.runtime.onUpdateAvailable.addListener((event) => {
    if (event.version != currentVersion) {
        updateRequired = true;
    }
    ;
    browser.tabs.create({
        title: "Update Available (Web++)",
        url: browser.runtime.getURL("ui/update/update.html"),
    });
});
